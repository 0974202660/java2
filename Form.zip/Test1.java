package j2testgiuaky;


import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author minhdq
 */
public class Test1 implements Serializable{
    public String name;
    public boolean gender = false;
    public String skill;
    public String nganh;
    
}
